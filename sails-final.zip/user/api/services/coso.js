module.exports = (data) => {
	sails.log.info("entrando a coso");
	sails.log.info(data);
	sails.log.info("saliendo de coso");
};